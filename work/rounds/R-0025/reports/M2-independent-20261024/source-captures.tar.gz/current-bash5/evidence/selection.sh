set -euo pipefail
if [[ -v DETRAN_STACK_STATE_DIR ]]; then
  report_dir="${DETRAN_STACK_STATE_DIR:-.}"
elif [[ -v TMPDIR ]]; then
  report_dir="${TMPDIR:-.}/detran-stack"
else
  report_dir=/tmp/detran-stack
fi
printf '%s\n' "$report_dir"
