# ADR-0059: RAIT candidate universe linearization

## Status

Renumerada para [ADR-0062](ADR-0062-rait-candidate-universe-linearization.md).

Redirecionamento sem conteúdo normativo, pela política da [ADR-0035](ADR-0035-adr-numbering-policy.md).
Aplicação atual: R-0025, reconciliação PR211 com main7dfab8bd em2026-10-23. ADR-0059 permanece com `ADR-0059-official-test-proof-anchor-compatibility.md`, integrado primeiro em main. ADR-0060 não colide e permanece intacto.
