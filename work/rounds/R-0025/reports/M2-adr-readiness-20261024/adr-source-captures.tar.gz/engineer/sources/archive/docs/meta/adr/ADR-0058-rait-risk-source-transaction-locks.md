# ADR-0058: RAIT risk source transaction locks

## Status

Renumerada para [ADR-0061](ADR-0061-rait-risk-source-transaction-locks.md).

Redirecionamento sem conteúdo normativo, pela política da [ADR-0035](ADR-0035-adr-numbering-policy.md).
Aplicação atual: R-0025, reconciliação PR211 com main7dfab8bd em2026-10-23. ADR-0058 permanece com `ADR-0058-scorecard-collector-fidelity.md`, integrado primeiro em main. ADR-0060 não colide e permanece intacto.
