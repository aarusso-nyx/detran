// External orchestration only; does not author readings or modify repository source.
import { readFileSync, writeFileSync, mkdirSync, existsSync, readdirSync, lstatSync, readlinkSync, realpathSync } from 'node:fs';
import { join, resolve } from 'node:path';
import { createRequire } from 'node:module';
import { spawn, execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';

const [rootArg, candidate, outputArg, execute, release] = process.argv.slice(2);
const planRoot = '/Volumes/Development/.codex/artifacts/detran/campaign-m1-reassessment-v2-20261023';
if (!rootArg || !/^[a-f0-9]{40}$/.test(candidate ?? '') || !outputArg || execute !== '--execute-frozen-candidate')
  throw Error('Usage: node execute.mjs ROOT EXACT40SHA NEW_OUTPUT_DIR --execute-frozen-candidate');
const root = resolve(rootArg), out = resolve(outputArg);
if (process.version !== 'v24.20.0') throw Error(`Actual Node guard: ${process.version}`);
const git = (...args) => execFileSync('git', args, {cwd:root, encoding:'utf8',maxBuffer:256*1024*1024}).trim();
const sameHead = () => { if (git('rev-parse','HEAD') !== candidate) throw Error('Frozen HEAD changed'); };
sameHead();
const initialStatus = git('status','--porcelain=v1','--untracked-files=all');
if (initialStatus) throw Error('New candidate must start completely clean');
if (release !== '--shared-window-released') throw Error('Explicit shared-window release required');
if (out===root || out.startsWith(root+'/')) throw Error('Capture output must be outside source root');
if (execFileSync('pnpm',['--version'],{cwd:root,encoding:'utf8'}).trim()!=='9.15.0') throw Error('pnpm drift');
if (existsSync(out)) throw Error('New immutable capture directory required');
mkdirSync(out,{recursive:true});
const read = path => JSON.parse(readFileSync(path,'utf8'));
const save = (name,value) => writeFileSync(join(out,name), JSON.stringify(value,null,2)+'\n',{flag:'wx'});
const pkg = join(root,'node_modules/@aarusso-nyx/devai');
if (read(join(pkg,'package.json')).version !== '2.7.0') throw Error('Provider identity drift');
const schema = read(join(pkg,'dist/runtime/index/schemas/sensor-reading.schema.json'));
const require = createRequire(join(root,'node_modules/.pnpm/node_modules/ajv/package.json'));
const Ajv = require('./dist/2020.js').default;
const ajv = new Ajv({strict:false,allErrors:true});
require('ajv-formats')(ajv);
const validate = ajv.compile(schema);
const {parseCommandDocument,unwrapCommandDocument} = await import(join(root,'tools/devai/scorecard-output.mjs'));
const registry = read(join(pkg,'dist/law/policy/sensor-registry.json')).entries;
const presets = read(join(pkg,'dist/law/policy/sense-presets.json'));
const sweep = presets.presets.find(x=>x.name==='sweep');
const second = presets.selection_effect_rule.sweep_second_pass.split(',');
const inputs = read(join(root,'law/policy/scorecard-sensor-inputs.json')).inputs;
const separate = ['build','unit_test','integration_test','e2e_test','migration_check','inventory_regeneration'];
const first = sweep.members.filter(k=>!second.includes(k));
const readKinds = registry.filter(x=>x.effect==='read').map(x=>x.kind);
if (readKinds.length!==sweep.members.length || readKinds.some(k=>!sweep.members.includes(k))) throw Error('Incomplete sweep');
const required = [...separate,...first,...second];
if (required.length!==55 || new Set(required).size!==55) throw Error('Installed required population drift');
for (const [rel,frozen] of [['test-tasks.json','original-test-tasks.json'],['law/policy/scorecard-sensor-inputs.json','original-sensor-inputs.json']]) if (!readFileSync(join(root,rel)).equals(readFileSync(join(planRoot,frozen)))) throw Error('Original descriptor/input bytes changed: '+rel);
if (JSON.stringify(first)!==JSON.stringify(read(join(planRoot,'plan.json')).first)||JSON.stringify(second)!==JSON.stringify(read(join(planRoot,'plan.json')).second)) throw Error('Original selection drift');
save('context.json',{candidate,tree:git('rev-parse','HEAD^{tree}'),provider:'2.7.0',runtime:process.version,root,round:'R-0042',required,first,second,registry,started:new Date().toISOString()});
const preservation = {};
for (const p of ['.devai/state/evidence-chain.json','record/proofs/chain.json','test-tasks.json','.devai/config/invariant-producers.json','law/policy/scorecard-sensor-inputs.json']) {
 const b=readFileSync(join(root,p));preservation[p]={sha256:createHash('sha256').update(b).digest('hex'),bytes:b.length};
}
save('preservation-before.json',preservation);
let active, interrupted;
for (const sig of ['SIGINT','SIGTERM']) process.on(sig,()=>{ interrupted=sig; if(active?.pid) try{process.kill(-active.pid,sig);}catch{} });
async function capture(label,argv,timeout=2400000) {
 sameHead();
 if(interrupted)throw Error('External capture interrupted by '+interrupted);
 if(existsSync(join(out,label+'.json')))throw Error(`Duplicate capture ${label}`);
 const started=new Date().toISOString();
 console.log(`${started} START ${label}`);
 let stdout='',stderr='',timedOut=false;
 const result=await new Promise((done)=>{
  const child=spawn(argv[0],argv.slice(1),{cwd:root,env:process.env,detached:true,stdio:['ignore','pipe','pipe']});active=child;
  child.stdout.on('data',b=>stdout+=b);child.stderr.on('data',b=>stderr+=b);
  let force;
  const timer=setTimeout(()=>{timedOut=true;try{process.kill(-child.pid,'SIGTERM');force=setTimeout(()=>{try{process.kill(-child.pid,'SIGKILL');}catch{}},10000);}catch{}},timeout);
  child.on('error',e=>stderr+=String(e));
  child.on('close',(code,signal)=>{clearTimeout(timer);clearTimeout(force);active=undefined;done({code,signal});});
 });
 const value={argv,started,finished:new Date().toISOString(),...result,timedOut,stdout,stderr};save(label+'.json',value);
 console.log(`${value.finished} END ${label} exit=${result.code} timeout=${timedOut}`);
 if(interrupted)throw Error('External capture interrupted by '+interrupted+'; raw capture preserved');
 return value;
}
const cli=(...args)=>['pnpm','exec','devai',...args];
function readingsOf(raw){
 const doc=unwrapCommandDocument(parseCommandDocument(raw)), found=new Map();
 const visit=x=>{
  if(!x || typeof x!=='object')return;
  if(x.id && x.sensor?.kind){found.set(x.id,x);return;}
  if(Array.isArray(x)){for(const y of x)visit(y);return;}
  for(const [k,v]of Object.entries(x)) {
   if((k==='stdout'||k==='stderr')&&typeof v==='string'){try{visit(JSON.parse(v));}catch{}}
   else if(typeof v==='object')visit(v);
  }
 };
 visit(doc);return [...found.values()];
}
const observations=[], attempts=[];

const digest=b=>createHash('sha256').update(b).digest('hex');
const originalChain=read(join(root,'record/proofs/chain.json'));
const initialIds=new Set();
function fileInventory(paths) {
 return paths.map(p=>{const s=lstatSync(join(root,p));return {path:p,bytes:s.size,mtime_ms:s.mtimeMs,symlink:s.isSymbolicLink(),...(s.isSymbolicLink()?{target:readlinkSync(join(root,p))}:s.isFile()?{sha256:digest(readFileSync(join(root,p)))}:{})};});
}
function pathsBelow(dir){if(!existsSync(join(root,dir)))return [];return readdirSync(join(root,dir),{withFileTypes:true}).flatMap(e=>e.isDirectory()?pathsBelow(join(dir,e.name)):[join(dir,e.name)]);}
const trackedPaths=new Set(execFileSync('git',['ls-files','-z'],{cwd:root}).toString().split('\0').filter(Boolean));
const baselineStore=fileInventory(pathsBelow('.devai/state/sensor-readings'));
for (const x of baselineStore) {try{initialIds.add(read(join(root,x.path)).id);}catch{}}
save('baseline-store-bodies.json',{source:candidate,chain:originalChain,store:baselineStore,bodies:fileInventory([...pathsBelow('.devai/state/inventory'),...pathsBelow('.devai/state/sensors'),...pathsBelow('record/proofs/sensors')]),tracked_sensor_files:baselineStore.filter(x=>trackedPaths.has(x.path)).length});
// Full ignored-file names + lstat provenance, without following symlink directories.
const ignored=execFileSync('git',['ls-files','--others','--ignored','--exclude-standard','-z'],{cwd:root,maxBuffer:256*1024*1024}).toString().split('\0').filter(Boolean);
save('baseline-ignored-files.json',ignored.map(path=>{const s=lstatSync(join(root,path));return {path,bytes:s.size,mtime_ms:s.mtimeMs,symlink:s.isSymbolicLink(),...(s.isSymbolicLink()?{target:readlinkSync(join(root,path))}:{}),content_hash_scope:path.startsWith('.devai/')?'see governance ignored hashes':'metadata-only dependency/build provenance'};}));
save('baseline-ignored-governance-hashes.json',fileInventory(ignored.filter(p=>p.startsWith('.devai/'))));
function preserveCoverage(label){const files=pathsBelow('coverage');const destination=join(out,label);mkdirSync(destination,{recursive:true});const rows=[];for(const path of files){const st=lstatSync(join(root,path));if(!st.isFile())continue;const bytes=readFileSync(join(root,path)),target=join(destination,path);mkdirSync(resolve(target,'..'),{recursive:true});writeFileSync(target,bytes,{flag:'wx'});rows.push({path,sha256:digest(bytes),bytes:bytes.length,retained_path:target});}save(label+'-manifest.json',rows);}
 preserveCoverage('baseline-coverage-retained');
const c6=read(join(root,'.devai/config/invariant-producers.json'));
if(c6.bindings?.length!==0)throw Error('C6 bindings must remain empty');
const invariants=()=>{
 sameHead();
 const current=read(join(root,'record/proofs/chain.json'));
 if(JSON.stringify(current.records.slice(0,originalChain.records.length))!==JSON.stringify(originalChain.records))throw Error('Original chain prefix mutation');
 for(const rel of ['test-tasks.json','law/policy/scorecard-sensor-inputs.json','.devai/config/invariant-producers.json','.devai/state/evidence-chain.json'])if(digest(readFileSync(join(root,rel)))!==preservation[rel].sha256)throw Error('Frozen authority/input bytes changed: '+rel);
 for(const f of baselineStore)if(digest(readFileSync(join(root,f.path)))!==f.sha256)throw Error('Historical reading altered: '+f.path);
 const dirt=execFileSync('git',['diff','HEAD','--name-only'],{cwd:root,encoding:'utf8'}).trim().split('\n').filter(Boolean);if(dirt.some(p=>p!=='record/proofs/chain.json'))throw Error('Tracked source changed: '+dirt);
};
function inventoryPool(label){
 const chain=read(join(root,'record/proofs/chain.json')),rows=[],groups=new Map();
 for(const sub of readdirSync(join(root,'.devai/state/sensor-readings')).filter(n=>n.startsWith('inventory_'))){
  let entries;try{entries=readdirSync(join(root,'.devai/state/sensor-readings',sub));}catch{continue;}
  for(const name of entries.filter(n=>n.endsWith('.json'))){const path=join('.devai/state/sensor-readings',sub,name);let b,d;try{b=readFileSync(join(root,path));d=JSON.parse(b);}catch{rows.push({path,included:false,reason:'unreadable-or-malformed'});continue;}
   const kind=d.sensor?.kind??sub,included=typeof d.duration_ms==='number'&&Number.isFinite(d.duration_ms)&&d.duration_ms>=0&&typeof kind==='string'&&kind.startsWith('inventory_');
   const sha256=digest(b);rows.push({path,id:d.id,sha256,kind,status:d.status,timestamp:d.timestamp,duration_ms:d.duration_ms,included,tracked_at_start:trackedPaths.has(path),present_at_start:initialIds.has(d.id),source_metrics:d.metrics,chain_bindings:chain.records.filter(r=>r.artifacts?.some(a=>a.path===path&&a.sha256===sha256)).map(r=>({id:r.id,sequence:r.sequence,head:r.context?.git?.head_sha,artifacts:r.artifacts}))});
   if(included)groups.set(kind,[...(groups.get(kind)??[]),d.duration_ms]);
  }
 }
 const stat=ds=>({count:ds.length,p95_ms:[...ds].sort((a,b)=>a-b)[Math.ceil(.95*ds.length)-1],mean_ms:Math.round(ds.reduce((a,b)=>a+b,0)/ds.length)});
 const overall=stat([...groups.values()].flat()),expected={kinds_observed:groups.size,total_observations:overall.count,...(overall.count?{overall_p95_ms:overall.p95_ms,overall_mean_ms:overall.mean_ms}:{})};
 for(const [kind,ds]of groups)for(const [name,value]of Object.entries(stat(ds)))expected[kind+'_'+name]=value;
 const result={captured:new Date().toISOString(),source:candidate,rows,expected,no_status_head_latest_supersession_filter:true};save(label+'-input-pool.json',result);return result;
}
function bodyPublication(raw){
 const doc=unwrapCommandDocument(parseCommandDocument(raw));let report;
 const visit=x=>{if(!x||typeof x!=='object')return;if(Array.isArray(x.regenerated)&&x.integration_head)report=x;for(const v of Object.values(x))if(typeof v==='object')visit(v);};visit(doc);
 if(!report)throw Error('No authentic regeneration publication report');
 const bodies=report.regenerated,schemas={inventory:'inventory.schema.json',inventory_api:'api-map.schema.json',inventory_routes:'routes-inventory.schema.json',inventory_data_model:'data-model-inventory.schema.json',inventory_rbac:'rbac-inventory.schema.json',inventory_data_handling:'data-model-inventory.schema.json',inventory_dep_graph:'dep-graph.schema.json',inventory_coverage:'coverage-matrix.schema.json'},checks=[];
 if(!report.ok||report.errors?.length||bodies.length!==8||new Set(bodies.map(b=>b.kind)).size!==8||report.integration_head!==candidate)throw Error('Incomplete/failed inventory publication');
 for(const body of bodies){
  if(!schemas[body.kind]||body.body_path.startsWith('/')||body.body_path.split('/').includes('..'))throw Error('Unexpected body identity/path');
  const physical=realpathSync(join(root,body.body_path));if(!physical.startsWith(realpathSync(root)+'/')||lstatSync(join(root,body.body_path)).isSymbolicLink())throw Error('Body physical-origin escape/symlink');
  const bytes=readFileSync(join(root,body.body_path));if(digest(bytes)!==body.sha256)throw Error('Published body hash differs');
  const content=JSON.parse(bytes),schemaName=schemas[body.kind];let validator=ajv.getSchema('https://devai.nyxk.com.br/schemas/'+schemaName);if(!validator)validator=ajv.compile(read(join(pkg,'dist/runtime/index/schemas',schemaName)));
  const strictValid=validator(content),errors=structuredClone(validator.errors??[]);
  // Mirror published native REVIEW allowance exactly: only top-level empty collection minItems.
  const admissibleReview=body.producer_status==='review'&&errors.length>0&&errors.every(e=>e.keyword==='minItems'&&/^\/[^/]+$/.test(e.instancePath)&&Array.isArray(content[e.instancePath.slice(1)])&&content[e.instancePath.slice(1)].length===0);
  if(!strictValid&&!admissibleReview)throw Error('Published body schema refused '+body.kind+': '+JSON.stringify(errors));
  if(body.kind==='inventory'){if(content.integration_head!==candidate)throw Error('Inventory X binding absent');}
  else {const binding=body.producer_reading?.input_binding;if(binding?.integration_head!==candidate||binding.integration_tree!==git('rev-parse','HEAD^{tree}')||binding.body_sha256!==body.sha256)throw Error('Body producer binding differs from X');}
  checks.push({...body,physical_origin:physical,schema:schemaName,strict_schema_valid:strictValid,native_review_empty_collection_allowance:admissibleReview,errors});
 }
 save('inventory-publication-validated.json',{source:candidate,report,checks});
}

async function sensor(kind,label){
 invariants();
 const beforeIds=new Set(pathsBelow('.devai/state/sensor-readings').filter(p=>p.endsWith('.json')).map(p=>{try{return read(join(root,p)).id;}catch{return undefined;}}));
 const pool=kind==='inventory_performance'?inventoryPool(label):undefined;
 let poolMismatch;
 const input=inputs[kind]??{};const entry=registry.find(x=>x.kind===kind);
 const mutates=entry.effect!=='read'||Boolean(input.taskId);
 const raw=await capture(label,cli('sense','run',kind,'--repo-root','.', '--round','R-0042','--input',JSON.stringify(input),...(mutates?['--as-role','inspector','--write']:[]),'--format','json'));
 const readings=readingsOf(raw); let publicationError; if(kind==='inventory_regeneration'){try{bodyPublication(raw);}catch(e){publicationError=String(e);save('inventory-publication-gap.json',{source:candidate,error:publicationError,raw:label+'.json'});}}
 attempts.push({kind,label,code:raw.code,timedOut:raw.timedOut,readings:readings.map(x=>x.id)});
 for(const [i,reading] of readings.entries()){
  if(beforeIds.has(reading.id))throw Error('Stale emission reuses pre-invocation ID '+reading.id);
  if(!validate(reading)){save(label+`-invalid-${i}.json`,{reading,errors:validate.errors});throw Error(`Installed schema rejected ${kind}`);}
  if(reading.sensor.kind!==kind)throw Error('Unexpected emitted kind');
  if(reading.metrics?.candidate_commit&&reading.metrics.candidate_commit!==candidate)throw Error('Task reading candidate mismatch');
  const file=label+`-reading-${i}.json`;save(file,reading);
  if(pool){const mismatch=Object.entries(pool.expected).filter(([k,v])=>reading.metrics?.[k]!==v);save(label+'-pool-reconciliation.json',{expected:pool.expected,actual:reading.metrics,mismatch});if(mismatch.length)poolMismatch=mismatch;}
  const receipt=await capture(label+`-record-${i}`,cli('sense','record','--repo-root','.', '--input',join(out,file),'--as-role','inspector','--write','--format','json'),60000);
  const doc=parseCommandDocument(receipt);
  if(receipt.code!==0 || doc?.ok!==true)throw Error(`Immediate official recording failed ${reading.id}; no next emission`);
  const canonical=join('.devai/state/sensor-readings',kind,reading.id+'.json'),canonicalHash=digest(readFileSync(join(root,canonical)));
  const bound=read(join(root,'record/proofs/chain.json')).records.filter(r=>r.context?.git?.head_sha===candidate&&r.artifacts?.some(a=>a.path===canonical&&a.sha256===canonicalHash));
  if(!bound.length)throw Error('Official receipt missing current-X canonical hash binding');
  save(label+`-canonical-${i}.json`,{path:canonical,sha256:canonicalHash,record_ids:bound.map(r=>r.id)});
  observations.push({reading,capture:label+'.json',record:label+`-record-${i}.json`,has_measurement_capture:true,capture_terminated:raw.timedOut||Boolean(raw.signal)});
 }
 invariants();
 if(poolMismatch)throw Error('Inventory pool mismatch preserved after official record');
 if(publicationError)throw Error('Inventory gap officially retained; stop dependent body claims; no producer retry: '+publicationError);
 save(label+'-disposition.json',{kind,reading_count:readings.length,code:raw.code,timedOut:raw.timedOut,observation_gap:readings.length===0});
 if(existsSync(join(out,'PAUSE_REQUEST'))){save(label+'-safe-pause.json',{source:candidate,no_active_child:!active,after_official_records:true,at:new Date().toISOString()});while(existsSync(join(out,'PAUSE_REQUEST')))await new Promise(r=>setTimeout(r,1000));invariants();}
}
try{
 await sensor('inventory_regeneration','first-inventory_regeneration');
 await sensor('build','separate-build');
 await capture('whole-source-coverage',['pnpm','exec','vitest','run','--config','tests/config/local.coverage.config.ts','--coverage.enabled=true']);
 preserveCoverage('fresh-X-coverage-retained');
 for(const k of separate.filter(k=>k!=='build'&&k!=='inventory_regeneration'))await sensor(k,'separate-'+k);
 for(const k of first)await sensor(k,'first-'+k);
 const e2e=observations.find(o=>o.reading.sensor.kind==='e2e_test');
 if(e2e?.reading.status==='fail')await sensor('e2e_test','same-X-e2e-retry');
 for(const k of second)await sensor(k,'second-'+k);
 save('observations.json',observations);save('attempts.json',attempts);
 const observedKinds=new Set(observations.map(o=>o.reading.sensor.kind));if(required.some(k=>!observedKinds.has(k)))throw Error('Required55 emission gap retained; no complete assessment claim');
 const audit=await capture('native-scorecard',cli('audit','scorecard','--repo-root','.', '--at',candidate,'--format','json'),60000);
 const score=unwrapCommandDocument(parseCommandDocument(audit));
 const selected=[];const walk=x=>{if(!x||typeof x!=='object')return;if(Array.isArray(x.sensor_readings))selected.push(...x.sensor_readings);for(const v of Object.values(x))if(typeof v==='object')walk(v);};walk(score);
 const chain=read(join(root,'record/proofs/chain.json'));
 const bindings=[...new Set(selected)].map(id=>{const rows=chain.records.filter(r=>r.context?.git?.head_sha===candidate&&r.artifacts?.some(a=>a.path.endsWith('/'+id+'.json')));if(!rows.length||initialIds.has(id)||!observations.some(o=>o.reading.id===id))throw Error('Scorecard selected non-current-X reading '+id);return {id,records:rows.map(r=>r.id)};});if(audit.code!==0||!score?.cells||score.cells.length!==45)throw Error('Native scorecard composition invalid/incomplete');
 save('current-X-scorecard-selection.json',{source:candidate,selected:bindings});
 invariants();
 const doctor=await capture('doctor',cli('doctor','--format','json'),60000);
 const verify=await capture('chain-verification',cli('evidence','verify','--scope','chain','--repo-root','.', '--show-head','--format','human'),60000);
 invariants();
 const finalChain=read(join(root,'record/proofs/chain.json'));
 save('final-canonical-custody.json',{source:candidate,original_prefix_records:originalChain.records.length,original_prefix_identical:true,chain:finalChain,new_records:finalChain.records.slice(originalChain.records.length),canonical_files:fileInventory(pathsBelow('.devai/state/sensor-readings').filter(p=>!baselineStore.some(b=>b.path===p))),doctor_exit:doctor.code,chain_verification_exit:verify.code});
 if(doctor.code!==0||verify.code!==0)throw Error('Final Doctor or chain verification failed; authentic receipts retained');
 save('execution-complete.json',{candidate,required_sensor_types:required.length,attempted:attempts.length,emitted_readings:observations.length,finished:new Date().toISOString(),note:'Coverage/native cell assessment and followup dispositions require inspection of exact captured evidence; no fabricated readiness claim.'});
}catch(error){save('execution-stopped.json',{candidate,message:String(error),attempts,observations,at:new Date().toISOString()});throw error;}
