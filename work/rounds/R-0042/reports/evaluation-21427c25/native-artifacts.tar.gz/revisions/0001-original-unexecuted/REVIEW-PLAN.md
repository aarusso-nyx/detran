# Inspector v2 dry plan — preparation only

No candidate X has been supplied. No runner, sensor, test, install, service, producer or RC was executed. The runner has not been syntax-executed; source review is requested before authorization. All files are outside repository roots. Original old74 artifacts remain untouched.

Intended root: `/Volumes/Development/.codex/worktrees/completion-roadmap/detran`, after parent completes official R0043 closeout/report retention, commits every source change, publishes and supplies exact40SHA X. Requires clean tracked and untracked status plus explicit shared-heavy-window release. Dependencies must already be fully materialized under frozen lock; this runner never installs. Actual Node24.20.0, pnpm9.15.0, installed DEVAI2.7.0. Active round R0042. No RC stage.

## Sequence

1. Outside-root immutable baseline capture: exact source/tree/runtime/provider; descriptor/input digests; complete canonical reading/body files and hashes; initial chain; all ignored filenames/lstat provenance, with ignored `.devai/` content hashes and pre-existing coverage bytes retained externally. Preserve the expected268 tracked readings; actual count is recorded, never enforced by purging. All historical raw files stay in place.
2. FIRST native action: `pnpm exec devai sense run inventory_regeneration --repo-root . --round R-0042 --input <unchanged-configured-input> --as-role inspector --write --format json`. No proof append, repository freeze file, output redirect or untracked source may precede this action. Baseline writes are outside root.
3. Capture authentic publication/readings; validate installed reading schema; require publication report.ok, no errors, all8 distinct original body kinds, physical in-root regular files, exact published hashes, installed body schemas and genuine X/tree bindings. Seven typed bodies bind through authentic `producer_reading.input_binding`; base inventory binds internally through `integration_head`. Preserve native REVIEW-only allowance for top-level empty collection minItems, separately disclosing strict schema result. Immediately official `sense record` each genuine reading and verify canonical hash/exact-X chain binding. If publication fails/partial, retain and record genuine gap, stop the run and dependent-body claims. Never retry producer on X.
4. Fresh build; full genuine source coverage through original local.coverage.config.ts; fresh unit/integration/E2E/migration; original47 first-pass read kinds (including native perf task) with unchanged inputs and roles. Old74 coverage or readings cannot substitute. Coverage originals/new outputs retained externally.
5. If this X's first E2E actually FAILS, one same-root original-budget E2E retry, immediate validation/record; native same-root supersession remains untouched. No retry for an old-source failure. Both final store readers run after all correction attempts.
6. Immediately before EACH inventory_performance invocation, enumerate all configured inventory_* directories and every JSON file, including prior inventory_performance outputs. Match native finite nonnegative top-level duration admission and fallback kind exactly; preserve historical status/source/latest/supersession populations without filtering. Persist ID/path/hash/source metrics/all matching chain bindings and expected per-kind/overall native statistics. Compare native result, then retain receipt; discrepancies stop later work after authentic recording.
7. Native scorecard exact-X; require45 cells (43 applicable +2 N/A), every selected ID emitted during this invocation and canonically bound at X, never from baseline. Preserve overall FAIL/REVIEW/UNKNOWN honestly. Doctor, native chain verify, final custody manifest and exact new canonical hashes/records. No claim that composition exit0 means scorecard PASS.

## Safety controls and budgets

Original selection and all7 test-tasks descriptor bytes are compared byte-for-byte with external copies; original sensor input bytes also fixed. Installed registry/preset must still match original55. Every operation checks fixedHEAD; each sensor boundary checks original chain prefix, legacy chain, descriptors/input/C6 bytes and every baseline reading hash. Only official tracked chain append may become dirty. Serial execution only; no source change, commit, merge, rebase or integration during epoch. One new immutable output directory; no retry/resume that resets chain. All raw stdout/stderr, exits, signals, outer timeouts, validation/official receipts remain immutable.

Native per-task timeout remains900000ms (15min). External collection cap remains2400000ms (40min), immediate record60000ms. Collection cap does not extend native budget. Previous native durations suggest roughly60–100min overall, with possible additional E2E7–15min; this is an estimate, no promised completion time.

For cooperative quiet-window pause, create external `<OUTPUT>/PAUSE_REQUEST`; runner finishes current sensor and its immediate record, writes `<label>-safe-pause.json` with no active child, then waits without capture timers. Remove request only on explicit resource release. Do not SIGSTOP during capture/record timers. No automatic cancellation of active tests.

## Pending review points / actual execution gate

- Parent supplies published clean X and explicit shared-window release. No placeholder or intended SHA is execution authority.
- Parent/cross-family review of external execute.mjs is pending. No syntax or behavior test has run during shared hold.
- Baseline ignored provenance inventories every ignored path/size/mtime/symlink; content hashes are complete for governance ignored files and canonical/body files, not every installed node_modules byte. Dependency closure identity remains exact package/lock/runtime and native input provenance; no altered package hashing protocol is introduced.
- Existing ignored or tracked generated bodies may cause a genuine native guard refusal. Never remove, edit or transplant them to make regeneration pass; record and stop.
- Raw wrapper output path remains the original expressly permitted R0036 location, under R0042 execution authority. No descriptor/wrapper refactor.
- C6 bindings remain empty; #211 remains unmerged. New canonical chain tail belongs only to X; final signedRC remains a later closeout candidate after actual224 integration.

Future command (X and fresh OUTPUT must be supplied, no execution now):

```sh
PATH=/Volumes/Development/runtimes/nvm/versions/node/v24.20.0/bin:$PATH node /Volumes/Development/.codex/artifacts/detran/campaign-m1-reassessment-v2-20261023/execute.mjs /Volumes/Development/.codex/worktrees/completion-roadmap/detran X OUTPUT --execute-frozen-candidate --shared-window-released
```
