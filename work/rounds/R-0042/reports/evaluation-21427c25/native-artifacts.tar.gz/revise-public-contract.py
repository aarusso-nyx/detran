from pathlib import Path
p=Path('/Volumes/Development/.codex/artifacts/detran/campaign-m1-reassessment-v2-20261023/execute.mjs');s=p.read_text()
s=s.replace("const root = resolve(rootArg), out = resolve(outputArg);", "const root = resolve(rootArg), out = resolve(outputArg);\nif(candidate!=='21427c25fe2e1c7977ca0311156d4c59d8cfea35'||root!=='/Volumes/Development/.codex/worktrees/completion-roadmap/detran')throw Error('Reviewed candidate/root identity mismatch');")
s=s.replace("const schema = read(join(pkg", "const identity=read(join(planRoot,'candidate-21427c25-static-identity.json'));\nconst sha256=b=>createHash('sha256').update(b).digest('hex');\nif(git('rev-parse','HEAD^{tree}')!==identity.tree||sha256(readFileSync(join(pkg,'dist/runtime/index/release-host.js')))!==identity.installed_package.release_host_sha256||sha256(readFileSync(join(pkg,'package.json')))!==identity.installed_package.manifest_sha256)throw Error('Reviewed package/tree drift');\nfor(const row of [...identity.official_generated_files,...identity.frozen_inputs,...identity.schema_files])if(sha256(readFileSync(join(root,row.path)))!==row.sha256)throw Error('Reviewed identity bytes drift: '+row.path);\nconst schema = read(join(pkg")
# Baseline original body bytes are copied before producer can overwrite legitimate ignored outputs.
s=s.replace("const baselineStore=fileInventory", "const bodyPaths={inventory:'.devai/state/inventory/inventory.json',inventory_api:'.devai/state/sensors/inventory_api/api-map.json',inventory_routes:'.devai/state/sensors/inventory_routes/routes-angular.json',inventory_data_model:'.devai/state/sensors/inventory_data_model/data-model.json',inventory_rbac:'.devai/state/sensors/inventory_rbac/rbac.json',inventory_data_handling:'.devai/state/sensors/inventory_data_handling/data-model-pii.json',inventory_dep_graph:'.devai/state/sensors/inventory_dep_graph/dep-graph.json',inventory_coverage:'.devai/state/sensors/inventory_coverage/coverage-matrix.json'};\nconst retainedPriorBodies=[];\nfor(const path of [...pathsBelow('.devai/state/inventory'),...pathsBelow('.devai/state/sensors'),...pathsBelow('record/proofs/sensors')]){const bytes=readFileSync(join(root,path)),target=join(out,'baseline-body-bytes',path);mkdirSync(resolve(target,'..'),{recursive:true});writeFileSync(target,bytes,{flag:'wx'});retainedPriorBodies.push({path,sha256:digest(bytes),bytes:bytes.length,retained_path:target});}\nsave('baseline-body-retained-manifest.json',retainedPriorBodies);\nconst ignoredBodies=Object.values(bodyPaths).map(path=>({path,tracked:trackedPaths.has(path),ignored:subprocessIgnored(path)}));\nfunction subprocessIgnored(path){try{execFileSync('git',['check-ignore','--no-index','-q',path],{cwd:root});return true;}catch{return false;}}\nif(ignoredBodies.some(x=>x.tracked||!x.ignored))throw Error('Unexpected nonignored/tracked native output path; separate review required');\nsave('official-body-output-paths.json',ignoredBodies);\nconst baselineStore=fileInventory")
s=s.replace("const dirt=execFileSync", "const untracked=execFileSync('git',['ls-files','--others','--exclude-standard','-z'],{cwd:root}).toString().split('\\0').filter(Boolean);if(untracked.length)throw Error('Untracked source drift: '+untracked);\n const dirt=execFileSync")
a=s.index('function bodyPublication(raw)');b=s.index('\nasync function sensor',a)
s=s[:a]+r'''function bodyPublication(reading){
 const m=reading.metrics??{},schemas={inventory:'inventory.schema.json',inventory_api:'api-map.schema.json',inventory_routes:'routes-inventory.schema.json',inventory_data_model:'data-model-inventory.schema.json',inventory_rbac:'rbac-inventory.schema.json',inventory_data_handling:'data-model-inventory.schema.json',inventory_dep_graph:'dep-graph.schema.json',inventory_coverage:'coverage-matrix.schema.json'},checks=[];
 if(!['pass','review'].includes(reading.status)||m.error_count!==0||m.required_kinds!==7||m.missing_required_kinds!==0||m.kinds_touched!==7||m.integration_head!==candidate||m.integration_tree!==identity.tree)throw Error('Public reading reports partial/failed/unbound regeneration');
 for(const [kind,path]of Object.entries(bodyPaths)){
  const physical=realpathSync(join(root,path));if(!physical.startsWith(realpathSync(root)+'/')||!lstatSync(join(root,path)).isFile()||lstatSync(join(root,path)).isSymbolicLink())throw Error('Body physical-origin escape/symlink');
  const bytes=readFileSync(join(root,path)),sha=digest(bytes),bindingKey=kind==='inventory'?'inventory_body_sha256':kind+'_input_sha256';if(sha!==m[bindingKey])throw Error('Public body digest differs: '+kind);
  const content=JSON.parse(bytes),schemaName=schemas[kind];let validator=ajv.getSchema('https://devai.nyxk.com.br/schemas/'+schemaName);if(!validator)validator=ajv.compile(read(join(pkg,'dist/runtime/index/schemas',schemaName)));
  const strictValid=validator(content),errors=structuredClone(validator.errors??[]),producerStatus=kind==='inventory'?'pass':m[kind+'_status'];
  const reviewAllowance=producerStatus==='review'&&errors.length>0&&errors.every(e=>e.keyword==='minItems'&&/^\/[^/]+$/.test(e.instancePath)&&Array.isArray(content[e.instancePath.slice(1)])&&content[e.instancePath.slice(1)].length===0);
  if(!strictValid&&!reviewAllowance)throw Error('Published body schema refused '+kind+': '+JSON.stringify(errors));
  if(kind==='inventory'&&content.integration_head!==candidate)throw Error('Inventory body X binding differs');
  if(kind!=='inventory'&&!['pass','review'].includes(producerStatus))throw Error('Invalid public producer status');
  checks.push({kind,path,physical_origin:physical,sha256:sha,public_metric_binding:bindingKey,source_commit:m.integration_head,source_tree:m.integration_tree,producer_status:producerStatus,schema:schemaName,strict_schema_valid:strictValid,native_review_empty_collection_allowance:reviewAllowance,errors});
  const target=join(out,'published-body-bytes',path);mkdirSync(resolve(target,'..'),{recursive:true});writeFileSync(target,bytes,{flag:'wx'});
 }
 save('inventory-publication-validated.json',{source:candidate,public_reading_id:reading.id,public_reading_metrics:m,checks,no_private_report_or_API_used:true});
}
function coverageBoundary(label){
 const files=['coverage/coverage-final.json','coverage/coverage-v8.json','coverage/coverage-summary.json','coverage/population.json'];
 const before=files.map(path=>({path,...existsSync(join(root,path))?{exists:true,...fileInventory([path])[0]}:{exists:false}}));save(label+'-before-artifacts.json',{at:new Date().toISOString(),files:before,existing_runs:pathsBelow('.devai/local/rounds/R-0036/coverage-runs')});return {time:Date.now(),before};
}
function validateFreshCoverage(label,raw,before){
 preserveCoverage(label+'-retained');
 let error;
 try{
  if(raw.code!==0||raw.signal||raw.timedOut)throw Error('Coverage did not complete successfully');
  const paths=['coverage/coverage-final.json','coverage/coverage-v8.json','coverage/coverage-summary.json','coverage/population.json'];
  const rows=fileInventory(paths);for(const row of rows)if(row.mtime_ms<before.time)throw Error('Coverage artifact not fresh: '+row.path);
  const side=read(join(root,'coverage/population.json')),report=readFileSync(join(root,'coverage/coverage-final.json')),v8=readFileSync(join(root,'coverage/coverage-v8.json'));
  if(side.binding?.commit!==candidate||side.binding.selector!=='full-suite'||side.binding.reportSha256!==digest(report)||side.lineCounters?.rawReportSha256!==digest(v8)||side.population!=='local'||!side.filesMeasured||!side.declaredTestFiles?.length||JSON.stringify(side.declaredTestFiles)!==JSON.stringify(side.executedTestFiles))throw Error('Coverage full-suite/hash/X population binding refused');
  save(label+'-freshness-validated.json',{source:candidate,sidecar:side,files:rows,execution:label+'.json'});
 }catch(e){error=String(e);save(label+'-freshness-gap.json',{source:candidate,error,execution:label+'.json'});}
 if(error)throw Error(error+'; stop before any stale dependent coverage claim');
}
''' +s[b:]
s=s.replace("const beforeIds=new Set(","const beforeIds=new Set(")
s=s.replace("const readings=readingsOf(raw); let publicationError; if(kind==='inventory_regeneration'){try{bodyPublication(raw);}","const readings=readingsOf(raw); let publicationError; if(kind==='inventory_regeneration'){try{if(readings.length!==1)throw Error('Expected one public regeneration reading');bodyPublication(readings[0]);}")
s=s.replace("if(beforeIds.has(reading.id))throw Error('Stale emission reuses pre-invocation ID '+reading.id);", "// Published resolver may legitimately reuse identical deterministic measurement IDs; retain fresh action capture + exact-byte official X binding.\n  const nativeIdReuse=beforeIds.has(reading.id);")
s=s.replace("save(label+`-canonical-${i}.json`,{path:canonical,sha256:canonicalHash,record_ids:bound.map(r=>r.id)});", "save(label+`-canonical-${i}.json`,{path:canonical,sha256:canonicalHash,record_ids:bound.map(r=>r.id),native_id_reuse:nativeIdReuse,fresh_action_capture:label+'.json'});")
s=s.replace("await capture('whole-source-coverage',['pnpm','exec','vitest','run','--config','tests/config/local.coverage.config.ts','--coverage.enabled=true']);\n preserveCoverage('fresh-X-coverage-retained');", "const beforeCoverage=coverageBoundary('whole-source-coverage');\n const coverage=await capture('whole-source-coverage',['pnpm','exec','vitest','run','--config','tests/config/local.coverage.config.ts','--coverage.enabled=true']);\n validateFreshCoverage('whole-source-coverage',coverage,beforeCoverage);")
s=s.replace("for(const k of first)await sensor(k,'first-'+k);", "for(const k of first){await sensor(k,'first-'+k);if(k==='test_coverage_depth')preserveCoverage('native-test-coverage-depth-followup');}")
a=s.index(' const bindings=[...new Set(selected)]');b=s.index(" invariants();\n const doctor=",a)
s=s[:a]+r''' if(audit.code!==0||score?.integration_head!==candidate||!Array.isArray(score.cells)||score.cells.length!==45)throw Error('Native scorecard composition invalid/incomplete/X mismatch');
 const grid=new Set(score.cells.map(c=>c.substrate+':'+c.property)),expectedGrid=Array.from({length:5},(_,f)=>Array.from({length:9},(_,t)=>'F'+(f+1)+':T'+(t+1))).flat();
 if(grid.size!==45||expectedGrid.some(k=>!grid.has(k)))throw Error('Scorecard unique45 grid differs');
 const na=score.cells.filter(c=>c.verdict==='N/A').map(c=>c.substrate+':'+c.property).sort();if(JSON.stringify(na)!==JSON.stringify(['F1:T1','F4:T5']))throw Error('Original two N/A cells differ');
 const bindings=[...new Set(selected)].map(id=>{
  const emitted=observations.find(o=>o.reading.id===id);if(!emitted)throw Error('Scorecard ID lacks fresh native emission '+id);
  const path=join('.devai/state/sensor-readings',emitted.reading.sensor.kind,id+'.json'),bytes=readFileSync(join(root,path)),sha=digest(bytes);
  if(JSON.stringify(JSON.parse(bytes))!==JSON.stringify(emitted.reading))throw Error('Selected canonical bytes differ from authentic emitted measurement');
  const rows=chain.records.filter(r=>r.action==='sense.readings.record'&&r.context?.git?.head_sha===candidate&&r.artifacts?.some(a=>a.path===path&&a.sha256===sha));if(!rows.length)throw Error('Selected reading lacks exact canonical hash binding at X');
  return {id,path,sha256:sha,source:candidate,fresh_action_capture:emitted.capture,native_historical_id_reuse:initialIds.has(id),records:rows.map(r=>r.id)};
 });
 save('current-X-scorecard-selection.json',{source:candidate,grid:[...grid],original_NA:na,selected:bindings});
''' +s[b:]
s=s.replace("save('final-canonical-custody.json',{source:candidate", "const newArtifacts=[];for(const rec of finalChain.records.slice(originalChain.records.length)){if(rec.context?.git?.head_sha!==candidate)throw Error('New chain record source differs');for(const artifact of rec.artifacts??[]){const bytes=readFileSync(join(root,artifact.path));if(digest(bytes)!==artifact.sha256)throw Error('Final new-record artifact hash mismatch: '+artifact.path);newArtifacts.push({record_id:rec.id,source:candidate,...artifact,bytes:bytes.length});}}\n save('final-canonical-custody.json',{new_artifacts_verified:newArtifacts,source:candidate")
s=s.replace("try{b=readFileSync(join(root,path));d=JSON.parse(b);}catch", "try{b=readFileSync(join(root,path));d=JSON.parse(b);if(!d||typeof d!=='object')throw Error('not an object');}catch")
p.write_text(s)
