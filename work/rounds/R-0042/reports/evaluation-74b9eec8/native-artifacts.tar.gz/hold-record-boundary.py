from pathlib import Path
import os,time,json,signal,datetime
out=Path('/Volumes/Development/.codex/artifacts/detran/campaign-m1-reassessment-20261023/epoch-74b9eec8-materialized')
log=out.parent/'epoch-74b9eec8-materialized2.log'
prior={p.name for p in out.glob('*-record-*.json')}
os.kill(60363,signal.SIGCONT)
while True:
 fresh=[p for p in out.glob('*-record-*.json') if p.name not in prior]
 for p in fresh:
  try:x=json.loads(p.read_text())
  except (OSError,json.JSONDecodeError):continue
  if x.get('code')!=0:continue
  os.kill(60363,signal.SIGSTOP)
  time.sleep(.02)
  text=log.read_text().splitlines();last=text[-1]
  # A saved record capture means its timer was cleared. If the next capture
  # already started, drain it unchanged and try the next completed record.
  label=p.name[:-5]
  idx=next((i for i,s in enumerate(text) if ' START '+label in s),-1)
  newer=[s for s in text[idx+1:] if ' START ' in s]
  if newer:
   prior.add(p.name);os.kill(60363,signal.SIGCONT);continue
  (out/'quiet-window2-safe-hold.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pid':60363,'state':'SIGSTOP','after_completed_record_capture':p.name,'record_code':x['code'],'record_timedOut':x['timedOut'],'last_log':last,'no_new_capture_started':True,'note':'Saved capture proves its close-handler cleared timer; pending completed git rev-parse before next START can be reaped on resume. No heavy task started.'},indent=2)+'\n')
  print('SAFE_RECORD_BOUNDARY_HELD',p.name,flush=True);raise SystemExit
 time.sleep(.001)
