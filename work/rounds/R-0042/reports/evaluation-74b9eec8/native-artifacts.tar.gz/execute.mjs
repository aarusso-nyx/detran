// External orchestration only; does not author readings or modify repository source.
import { readFileSync, writeFileSync, mkdirSync, existsSync } from 'node:fs';
import { join, resolve } from 'node:path';
import { createRequire } from 'node:module';
import { spawn, execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';

const [rootArg, candidate, outputArg, execute, priorEpochArg] = process.argv.slice(2);
if (!rootArg || !/^[a-f0-9]{40}$/.test(candidate ?? '') || !outputArg || execute !== '--execute-frozen-candidate')
  throw Error('Usage: node execute.mjs ROOT EXACT40SHA NEW_OUTPUT_DIR --execute-frozen-candidate');
const root = resolve(rootArg), out = resolve(outputArg);
if (process.version !== 'v24.20.0') throw Error(`Actual Node guard: ${process.version}`);
const git = (...args) => execFileSync('git', args, {cwd:root, encoding:'utf8'}).trim();
const sameHead = () => { if (git('rev-parse','HEAD') !== candidate) throw Error('Frozen HEAD changed'); };
sameHead();
const initialStatus = git('status','--porcelain=v1','--untracked-files=all');
let priorEpoch;
if (initialStatus) {
 if (!priorEpochArg || initialStatus !== 'M record/proofs/chain.json') throw Error('Only preserved official chain appends allowed on explicit retry');
 priorEpoch=resolve(priorEpochArg);
 const oldContext=JSON.parse(readFileSync(join(priorEpoch,'context.json'),'utf8'));
 if(oldContext.candidate!==candidate)throw Error('Retry source mismatch');
 const original=JSON.parse(execFileSync('git',['show',candidate+':record/proofs/chain.json'],{cwd:root,encoding:'utf8',maxBuffer:64*1024*1024}));
 const current=JSON.parse(readFileSync(join(root,'record/proofs/chain.json'),'utf8'));
 if(!Array.isArray(original.records)||!Array.isArray(current.records)||current.records.length<original.records.length||JSON.stringify(original.records)!==JSON.stringify(current.records.slice(0,original.records.length)))throw Error('Historical chain prefix changed');
} else if(priorEpochArg) { priorEpoch=resolve(priorEpochArg); }
if (existsSync(out)) throw Error('New immutable capture directory required');
mkdirSync(out,{recursive:true});
const read = path => JSON.parse(readFileSync(path,'utf8'));
const save = (name,value) => writeFileSync(join(out,name), JSON.stringify(value,null,2)+'\n',{flag:'wx'});
const pkg = join(root,'node_modules/@aarusso-nyx/devai');
if (read(join(pkg,'package.json')).version !== '2.7.0') throw Error('Provider identity drift');
const schema = read(join(pkg,'dist/runtime/index/schemas/sensor-reading.schema.json'));
const require = createRequire(join(root,'node_modules/.pnpm/node_modules/ajv/package.json'));
const Ajv = require('./dist/2020.js').default;
const ajv = new Ajv({strict:false});
require('ajv-formats')(ajv);
const validate = ajv.compile(schema);
const {parseCommandDocument,unwrapCommandDocument} = await import(join(root,'tools/devai/scorecard-output.mjs'));
const registry = read(join(pkg,'dist/law/policy/sensor-registry.json')).entries;
const presets = read(join(pkg,'dist/law/policy/sense-presets.json'));
const sweep = presets.presets.find(x=>x.name==='sweep');
const second = presets.selection_effect_rule.sweep_second_pass.split(',');
const inputs = read(join(root,'law/policy/scorecard-sensor-inputs.json')).inputs;
const separate = ['build','unit_test','integration_test','e2e_test','migration_check','inventory_regeneration'];
const first = sweep.members.filter(k=>!second.includes(k));
const readKinds = registry.filter(x=>x.effect==='read').map(x=>x.kind);
if (readKinds.length!==sweep.members.length || readKinds.some(k=>!sweep.members.includes(k))) throw Error('Incomplete sweep');
const required = [...separate,...first,...second];
if (required.length!==55 || new Set(required).size!==55) throw Error('Installed required population drift');
save('context.json',{candidate,tree:git('rev-parse','HEAD^{tree}'),provider:'2.7.0',runtime:process.version,root,round:'R-0042',required,first,second,registry,started:new Date().toISOString()});
const preservation = {};
for (const p of ['.devai/state/evidence-chain.json','record/proofs/chain.json','test-tasks.json','.devai/config/invariant-producers.json','law/policy/scorecard-sensor-inputs.json']) {
 const b=readFileSync(join(root,p));preservation[p]={sha256:createHash('sha256').update(b).digest('hex'),bytes:b.length};
}
save('preservation-before.json',preservation);
if(priorEpoch)save('retry-provenance.json',{reason:'Full recursive frozen-lock dependency materialization after authentic missing-tool negatives; original epoch retained',priorEpoch,candidate,initialStatus,legacyHistoryAndOriginalChainPrefixPreserved:true});
let active, interrupted;
for (const sig of ['SIGINT','SIGTERM']) process.on(sig,()=>{ interrupted=sig; if(active?.pid) try{process.kill(-active.pid,sig);}catch{} });
async function capture(label,argv,timeout=2400000) {
 sameHead();
 if(interrupted)throw Error('External capture interrupted by '+interrupted);
 if(existsSync(join(out,label+'.json')))throw Error(`Duplicate capture ${label}`);
 const started=new Date().toISOString();
 console.log(`${started} START ${label}`);
 let stdout='',stderr='',timedOut=false;
 const result=await new Promise((done)=>{
  const child=spawn(argv[0],argv.slice(1),{cwd:root,env:process.env,detached:true,stdio:['ignore','pipe','pipe']});active=child;
  child.stdout.on('data',b=>stdout+=b);child.stderr.on('data',b=>stderr+=b);
  let force;
  const timer=setTimeout(()=>{timedOut=true;try{process.kill(-child.pid,'SIGTERM');force=setTimeout(()=>{try{process.kill(-child.pid,'SIGKILL');}catch{}},10000);}catch{}},timeout);
  child.on('error',e=>stderr+=String(e));
  child.on('close',(code,signal)=>{clearTimeout(timer);clearTimeout(force);active=undefined;done({code,signal});});
 });
 const value={argv,started,finished:new Date().toISOString(),...result,timedOut,stdout,stderr};save(label+'.json',value);
 console.log(`${value.finished} END ${label} exit=${result.code} timeout=${timedOut}`);
 if(interrupted)throw Error('External capture interrupted by '+interrupted+'; raw capture preserved');
 return value;
}
const cli=(...args)=>['pnpm','exec','devai',...args];
function readingsOf(raw){
 const doc=unwrapCommandDocument(parseCommandDocument(raw)), found=new Map();
 const visit=x=>{
  if(!x || typeof x!=='object')return;
  if(x.id && x.sensor?.kind){found.set(x.id,x);return;}
  if(Array.isArray(x)){for(const y of x)visit(y);return;}
  for(const [k,v]of Object.entries(x)) {
   if((k==='stdout'||k==='stderr')&&typeof v==='string'){try{visit(JSON.parse(v));}catch{}}
   else if(typeof v==='object')visit(v);
  }
 };
 visit(doc);return [...found.values()];
}
const observations=[], attempts=[];
async function sensor(kind,label){
 const input=inputs[kind]??{};const entry=registry.find(x=>x.kind===kind);
 const mutates=entry.effect!=='read'||Boolean(input.taskId);
 const raw=await capture(label,cli('sense','run',kind,'--repo-root','.', '--round','R-0042','--input',JSON.stringify(input),...(mutates?['--as-role','inspector','--write']:[]),'--format','json'));
 const readings=readingsOf(raw); attempts.push({kind,label,code:raw.code,timedOut:raw.timedOut,readings:readings.map(x=>x.id)});
 for(const [i,reading] of readings.entries()){
  if(!validate(reading)){save(label+`-invalid-${i}.json`,{reading,errors:validate.errors});throw Error(`Installed schema rejected ${kind}`);}
  const file=label+`-reading-${i}.json`;save(file,reading);
  const receipt=await capture(label+`-record-${i}`,cli('sense','record','--repo-root','.', '--input',join(out,file),'--as-role','inspector','--write','--format','json'),60000);
  const doc=parseCommandDocument(receipt);
  if(receipt.code!==0 || doc?.ok!==true)throw Error(`Immediate official recording failed ${reading.id}; no next emission`);
  observations.push({reading,capture:label+'.json',record:label+`-record-${i}.json`,has_measurement_capture:true,capture_terminated:raw.timedOut||Boolean(raw.signal)});
 }
 save(label+'-disposition.json',{kind,reading_count:readings.length,code:raw.code,timedOut:raw.timedOut,observation_gap:readings.length===0});
}
try{
 await sensor('build','separate-build');
 await capture('whole-source-coverage',['pnpm','exec','vitest','run','--config','tests/config/local.coverage.config.ts','--coverage.enabled=true']);
 for(const k of separate.filter(k=>k!=='build'))await sensor(k,'separate-'+k);
 for(const k of first)await sensor(k,'first-'+k);
 for(const k of second)await sensor(k,'second-'+k);
 save('observations.json',observations);save('attempts.json',attempts);
 await capture('native-scorecard',cli('audit','scorecard','--repo-root','.', '--at',candidate,'--format','json'),60000);
 await capture('doctor',cli('doctor','--format','json'),60000);
 await capture('chain-verification',cli('evidence','verify','--scope','chain','--repo-root','.', '--show-head','--format','human'),60000);
 save('execution-complete.json',{candidate,required_sensor_types:required.length,attempted:attempts.length,emitted_readings:observations.length,finished:new Date().toISOString(),note:'Coverage/native cell assessment and followup dispositions require inspection of exact captured evidence; no fabricated readiness claim.'});
}catch(error){save('execution-stopped.json',{candidate,message:String(error),attempts,observations,at:new Date().toISOString()});throw error;}
