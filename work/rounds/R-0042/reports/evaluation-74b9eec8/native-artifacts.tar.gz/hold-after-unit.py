from pathlib import Path
import os,time,json,signal,subprocess,datetime
out=Path('/Volumes/Development/.codex/artifacts/detran/campaign-m1-reassessment-20261023/epoch-74b9eec8-materialized')
root=Path('/Volumes/Development/.codex/worktrees/milestone1-devai-adoption/detran')
reading=out/'separate-unit_test-reading-0.json'
while not reading.exists():
 os.kill(60363,0)
 time.sleep(.02)
os.kill(60363,signal.SIGSTOP)
time.sleep(3)
x=json.loads(reading.read_text());canonical=root/'.devai/state/sensor-readings'/x['sensor']['kind']/(x['id']+'.json')
chain=json.loads((root/'record/proofs/chain.json').read_text())
def recorded():
 if not canonical.exists() or json.loads(canonical.read_text())!=x:return False
 return any(any(a.get('path','').endswith('/'+x['id']+'.json') for a in e.get('artifacts',[])) for e in chain['records'])
if not recorded():
 # Orchestrator is stopped before dispatching its own record. Serialize explicit recording here.
 env=os.environ.copy();env['PATH']='/Volumes/Development/runtimes/nvm/versions/node/v24.20.0/bin:'+env['PATH']
 argv=['pnpm','exec','devai','sense','record','--repo-root','.', '--input',str(reading),'--as-role','inspector','--write','--format','json']
 result=subprocess.run(argv,cwd=root,env=env,text=True,capture_output=True)
 (out/'quiet-window-unit-record.json').write_text(json.dumps({'argv':argv,'code':result.returncode,'stdout':result.stdout,'stderr':result.stderr},indent=2)+'\n')
 if result.returncode:raise RuntimeError('Explicit native recording failed; runner remains held')
 chain=json.loads((root/'record/proofs/chain.json').read_text())
 if not recorded():raise RuntimeError('Canonical/chain binding missing; runner remains held')
(out/'quiet-window-hold.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reason':'Parent directed STYNX quiet-window; current unit completed and native reading officially recorded before hold','pid':60363,'state':'SIGSTOP','reading':x['id'],'reading_status':x['status'],'canonical_record_verified':True,'head':'74b9eec83cd10d981f5ec5923c0f82ad7b2c13b5','continuation':'Wait parent release; SIGCONT60363. Runner may safely repeat idempotent sense record if held before its own invocation; native canonical record already bound.'},indent=2)+'\n')
print('UNIT_RECORDED_RUNNER_HELD',x['id'],x['status'])
