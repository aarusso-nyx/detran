import json,pathlib,subprocess,hashlib,collections,math,datetime
root=pathlib.Path('/Volumes/Development/.codex/artifacts/detran/campaign-m1-reassessment-20261023');p=root/'epoch-74b9eec8-materialized';w=pathlib.Path('/Volumes/Development/.codex/worktrees/milestone1-devai-adoption/detran');sha='74b9eec83cd10d981f5ec5923c0f82ad7b2c13b5'
def h(b):return hashlib.sha256(b).hexdigest()
def save(name,x): (p/name).write_text(json.dumps(x,indent=2)+'\n')
def git(*args):return subprocess.check_output(['git',*args],cwd=w)
basebytes=git('show',sha+':record/proofs/chain.json');base=json.loads(basebytes);nowbytes=(w/'record/proofs/chain.json').read_bytes();now=json.loads(nowbytes)
assert now['records'][:len(base['records'])]==base['records']
rows=[]
for rec in now['records'][len(base['records']):]:
 assert rec['action']=='sense.readings.record' and rec['context']['git']['head_sha']==sha
 for a in rec['artifacts']:
  f=w/a['path']; b=f.read_bytes(); assert h(b)==a['sha256'];d=json.loads(b)
  rows.append({'path':a['path'],'sha256':h(b),'bytes':len(b),'reading_id':d['id'],'kind':d['sensor']['kind'],'status':d['status'],'timestamp':d['timestamp'],'supersedes':d.get('supersedes'),'record_id':rec['id'],'record_sequence':rec['sequence'],'record_timestamp':rec['timestamp'],'record_source_sha':rec['context']['git']['head_sha'],'record':rec,'tracked_at_frozen_source':subprocess.run(['git','cat-file','-e',sha+':'+a['path']],cwd=w,stderr=subprocess.DEVNULL).returncode==0})
assert len(rows)==57 and len(set(r['path'] for r in rows))==57
changed=git('diff','--name-only',sha).decode().splitlines();assert changed==['record/proofs/chain.json'],changed
# Validate all tracked legacy sensor bytes, not merely selected inventory inputs.
tracked=git('ls-tree','-r','--name-only',sha,'.devai/state/sensor-readings').decode().splitlines()
for rel in tracked: assert (w/rel).read_bytes()==git('show',sha+':'+rel),rel
obs=json.loads((p/'observations.json').read_text());assert len(obs)==55 and len(set(o['reading']['sensor']['kind'] for o in obs))==55
score=json.loads(json.loads((p/'native-scorecard.json').read_text())['stdout'])['result']['value'];save('scorecard-native-value.json',score)
pop=json.loads((p/'inventory-performance-input-population.json').read_text());native=json.loads((p/'second-inventory_performance-reading-0.json').read_text());groups=collections.defaultdict(list)
for r in pop['rows']:
 assert h((w/r['path']).read_bytes())==r['sha256']
 if r['included']:groups[r['kind']].append(r['duration_ms'])
expected={'kinds_observed':len(groups),'total_observations':sum(map(len,groups.values())),'overall_p95_ms':pop['computed_p95_ms'],'overall_mean_ms':pop['computed_mean_ms']}
for kind,ds in groups.items():expected.update({kind+'_count':len(ds),kind+'_p95_ms':sorted(ds)[math.ceil(.95*len(ds))-1],kind+'_mean_ms':math.floor(sum(ds)/len(ds)+.5)})
assert all(native['metrics'][k]==v for k,v in expected.items())
afterfiles={str(f.relative_to(w)) for f in (w/'.devai/state/sensor-readings').glob('inventory_*/*.json')};beforefiles={r['path'] for r in pop['rows']};assert afterfiles-beforefiles=={'.devai/state/sensor-readings/inventory_performance/'+native['id']+'.json'}
save('inventory-performance-reconciliation.json',{'snapshot_before_invocation':pop['captured'],'invocation':json.loads((p/'second-inventory_performance.json').read_text())['started'],'expected_metrics':expected,'native_metrics':native['metrics'],'all_metrics_match':True,'preexisting_files':len(beforefiles),'new_output_excluded_from_preinvocation_population':sorted(afterfiles-beforefiles),'historical_admitted':pop['selected_historical_count'],'same_SHA_scorecard_selection_is_separate':True,'filtering_or_purging':False})
manifest={'source_sha':sha,'captured':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base_chain_sha256':h(basebytes),'final_chain_sha256':h(nowbytes),'base_records':len(base['records']),'final_records':len(now['records']),'original_prefix_identical':True,'tracked_changes':changed,'original_tracked_sensor_files_preserved':len(tracked),'new_canonical_files':rows,'no_store_index_written':True,'chain_head':now['head']}
save('complete-canonical-custody-manifest.json',manifest)
summary={'source_sha':sha,'corrected_reading_kinds':len(obs),'corrected_reading_statuses':dict(collections.Counter(o['reading']['status'] for o in obs)),'all_new_readings_including_preserved_initial_negatives':len(rows),'native_scorecard_cells':len(score['cells']),'cell_verdicts':dict(collections.Counter(c['verdict'] for c in score['cells'])),'active_cell_verdicts':dict(collections.Counter(c['verdict'] for c in score['cells'] if c['verdict']!='N/A')),'overall':score['overall'],'substrates':score['substrate_aggregates'],'inventory_input_pool':{'preexisting_files':48,'tracked_historical_files':38,'admitted':31,'admitted_historical':24,'p95_ms':2917,'mean_ms':498},'heavy_work_held':True,'companion_or_same74_retry_executed':False,'process_complete':True}
for label in ['doctor','chain-verification','native-scorecard']:
 q=json.loads((p/(label+'.json')).read_text());summary[label]={k:q[k] for k in ['started','finished','code','timedOut']}
save('FINAL-SUMMARY.json',summary)
print(json.dumps(summary,indent=2))
