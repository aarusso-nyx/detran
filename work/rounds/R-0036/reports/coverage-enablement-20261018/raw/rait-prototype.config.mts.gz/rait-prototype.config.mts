import { resolve, dirname } from 'node:path';
import { createRequire } from 'node:module';
import { appendFileSync } from 'node:fs';
import original from '../../../../../apps/rait/web/vitest.config.ts';
const repoRoot=resolve(import.meta.dirname,'../../../../..');
const appRoot=resolve(repoRoot,'apps/rait/web');
const require=createRequire(resolve(appRoot,'package.json'));
const {defineConfig,mergeConfig}=await import(require.resolve('vitest/config'));
const ts=require('typescript') as typeof import('typescript');
const {angularJitApplicationTransform}=await import(require.resolve('@angular/compiler-cli'));
let program: import('typescript').Program | undefined;
function getProgram(){
 if(program) return program;
 const load=(file:string)=>{
  const path=resolve(appRoot,file);
  const config=ts.readConfigFile(path,ts.sys.readFile);
  if(config.error) throw new Error(ts.flattenDiagnosticMessageText(config.error.messageText,'\n'));
  return ts.parseJsonConfigFileContent(config.config,ts.sys,dirname(path));
 };
 const app=load('tsconfig.app.json'), spec=load('tsconfig.spec.json');
 program=ts.createProgram([...new Set([...spec.fileNames,...app.fileNames])],{
  ...spec.options,noEmit:false,noEmitOnError:false,sourceMap:true,inlineSourceMap:false,inlineSources:true,
 });
 return program;
}
const config=mergeConfig(original,defineConfig({root:appRoot,test:{coverage:{provider:'v8',enabled:true,reporter:['json','json-summary'],reportsDirectory:resolve(repoRoot,'.devai/local/rounds/R-0036/coverage-probe/rait-report'),include:['src/**/*.ts'],exclude:['src/**/*.spec.ts','src/test-setup.ts','src/testing/**']}}}));
config.plugins=[{
 name:'scorecard-angular-jit-with-original-source-map',enforce:'pre',
 transform(_code:string,id:string){
  if(!id.endsWith('.ts') || id.includes('node_modules')) return null;
  const p=getProgram(),source=p.getSourceFile(id);
  appendFileSync(resolve(repoRoot,'.devai/local/rounds/R-0036/coverage-probe/transform-ids.jsonl'),JSON.stringify({id,source:!!source})+'\n');
  if(!source) return null;
  let code:string|undefined,map:string|undefined;
  const emitted=p.emit(source,(name,content)=>{if(name.endsWith('.js'))code=content;else if(name.endsWith('.js.map'))map=content;},undefined,false,{before:[angularJitApplicationTransform(p)]});
  if(emitted.emitSkipped || code===undefined || map===undefined) {console.error('COVERAGE_EMIT_DIAGNOSTIC',id,emitted.diagnostics.map(d=>ts.flattenDiagnosticMessageText(d.messageText,'\n')));throw new Error('COVERAGE_ORIGINAL_SOURCE_MAP_MISSING:'+id);}
  return {code,map:JSON.parse(map)};
 },
}];
export default config;
