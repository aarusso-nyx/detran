import subprocess,pathlib,os,time,json,socket,datetime
out=pathlib.Path('/Users/aarusso/.config/devai/evidence/detran/post214-main-20261021/c7-transport-green');out.mkdir(exist_ok=True)
container='detran-post214-startup-diagnostic-'+str(os.getpid());image='postgis/postgis@sha256:44126d872ac91993766c341e369c539e8196614321765d36a6f1bab0419a5fa5';env=dict(os.environ);env['PATH']='/Users/aarusso/.nvm/versions/node/v24.15.0/bin:'+env['PATH']
def execute(name,argv,environment=env):
 start=datetime.datetime.now(datetime.timezone.utc).isoformat();r=subprocess.run(argv,env=environment,capture_output=True,text=True);(out/(name+'.json')).write_text(json.dumps({'classification':'ordinary-focused-diagnostic-not-attestation','argv':argv,'started_at':start,'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':r.returncode,'stdout':r.stdout,'stderr':r.stderr},indent=2)+'\n');return r
started=False
try:
 r=execute('docker-run',['docker','run','--detach','--rm','--name',container,'--platform','linux/amd64','--env','POSTGRES_DB=detran','--env','POSTGRES_USER=postgres','--env','POSTGRES_PASSWORD=postgres','--publish','127.0.0.1::5432',image]);r.check_returncode();started=True
 for n in range(90):
  logs=subprocess.run(['docker','logs',container],capture_output=True,text=True)
  if 'PostgreSQL init process complete; ready for start up.' in logs.stdout+logs.stderr and subprocess.run(['docker','exec',container,'pg_isready','-U','postgres','-d','detran'],capture_output=True).returncode==0:break
  time.sleep(1)
 else:raise RuntimeError('disposable fixture readiness failed')
 mapping=subprocess.check_output(['docker','port',container,'5432/tcp'],text=True).strip();port=mapping.rsplit(':',1)[1];base='postgresql://postgres:postgres@127.0.0.1:'+port;database='detran_r7_ctg1_a2'
 env.update({'DATABASE_URL':base+'/'+database,'DETRAN_TEST_DATABASE_URL':base+'/'+database,'STYNX_OWNER_DATABASE_URL':base+'/'+database,'STYNX_APP_DATABASE_URL':base+'/'+database+'?options=-c%20role%3Drole_app_backend','STYNX_READER_DATABASE_URL':base+'/'+database+'?options=-c%20role%3Drole_app_backend','DETRAN_RUNTIME_PROFILE':'test','DEVAI_DB_TESTS':'1','DETRAN_PRIORITY_BASELINE_ADMIN_DATABASE_URL':base+'/postgres','DETRAN_SEED_ADMIN_DATABASE_URL':base+'/postgres','DETRAN_SEED_SCRATCH_DATABASE_URL':base+'/detran_r7_ctg1_a2_seed_profiles','DETRAN_PRIORITY_UPGRADE_TEST_AUTHORIZED':'1','DETRAN_PRIORITY_UPGRADE_BASELINE_AUTHORIZED':'1','DETRAN_PRIORITY_UPGRADE_BASELINE_RESET_AUTHORIZED':'1','DETRAN_PRIORITY_UPGRADE_RESTORE_AUTHORIZED':'1','DETRAN_PRIORITY_UPGRADE_FULL_AUTHORIZED':'1','DB_HOST':'127.0.0.1','DB_PORT':port,'DB_USER':'postgres','DB_PASSWORD':'postgres','DB_NAME':database})
 execute('ddl',['pnpm','backend:db:reset']).check_returncode();execute('seed',['bash','backend/database/seed.sh']).check_returncode()
 argv=['pnpm','--filter','@detran/app','test:e2e','tests/e2e/portal-routes.e2e.spec.ts']
 # Fixed two-observation diagnostic; neither result can substitute for the full RC.
 results=[]
 for n in [1]:
  r=execute('unchanged-suite-'+str(n),argv);results.append(r.returncode);print('Focused unchanged suite',n,'exit',r.returncode,flush=True)
 (out/'summary.json').write_text(json.dumps({'classification':'ordinary-focused-diagnostic-only','candidate':'68d5c2a20d9c760831a3c2d0422c2b2968b87502','fixed_observations':1,'exitCodes':results,'original_hook_timeout_ms':60000,'original_test_timeout_ms':30000,'no_config_or_test_changes':True,'not_native_C6_or_RC_evidence':True},indent=2)+'\n')
finally:
 if started:
  execute('cleanup',['docker','rm','--force',container]).check_returncode();assert subprocess.run(['docker','inspect',container],capture_output=True).returncode!=0
